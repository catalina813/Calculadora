import {
  createButtonActiveGesture
} from "./chunk-AZ2FJCS5.js";
import {
  renderOptionLabel
} from "./chunk-BHLOKVQA.js";
import "./chunk-BYZAWBUX.js";
import {
  createLockController
} from "./chunk-ORCZUNWC.js";
import "./chunk-S2SDZHH7.js";
import "./chunk-GNZMTRDP.js";
import {
  BACKDROP,
  cleanupRootFocusTrapAccessibility,
  createDelegateController,
  createTriggerController,
  dismiss,
  eventMethod,
  isCancel,
  prepareOverlay,
  present,
  safeCall,
  setOverlayId
} from "./chunk-JA6VBZEZ.js";
import "./chunk-XFMBUHRC.js";
import {
  createAnimation
} from "./chunk-FSB6W4BM.js";
import "./chunk-3SX7BR72.js";
import "./chunk-B2DMNY7F.js";
import "./chunk-7GCWZYBP.js";
import "./chunk-DWC2MENN.js";
import {
  raf
} from "./chunk-LBH7LDCW.js";
import "./chunk-YIRVZL7S.js";
import {
  getClassMap
} from "./chunk-X6S6FZTM.js";
import {
  getIonMode
} from "./chunk-BPCRN7AY.js";
import {
  Host,
  createEvent,
  getElement,
  h,
  readTask,
  registerInstance
} from "./chunk-CHUIAFLQ.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-PAXKX5KU.js";

// node_modules/@ionic/core/dist/esm/ion-action-sheet.entry.js
var iosEnterAnimation = (baseEl) => {
  const baseAnimation = createAnimation();
  const backdropAnimation = createAnimation();
  const wrapperAnimation = createAnimation();
  backdropAnimation.addElement(baseEl.querySelector("ion-backdrop")).fromTo("opacity", 0.01, "var(--backdrop-opacity)").beforeStyles({
    "pointer-events": "none"
  }).afterClearStyles(["pointer-events"]);
  wrapperAnimation.addElement(baseEl.querySelector(".action-sheet-wrapper")).fromTo("transform", "translateY(100%)", "translateY(0%)");
  return baseAnimation.addElement(baseEl).easing("cubic-bezier(.36,.66,.04,1)").duration(400).addAnimation([backdropAnimation, wrapperAnimation]);
};
var iosLeaveAnimation = (baseEl) => {
  const baseAnimation = createAnimation();
  const backdropAnimation = createAnimation();
  const wrapperAnimation = createAnimation();
  backdropAnimation.addElement(baseEl.querySelector("ion-backdrop")).fromTo("opacity", "var(--backdrop-opacity)", 0);
  wrapperAnimation.addElement(baseEl.querySelector(".action-sheet-wrapper")).fromTo("transform", "translateY(0%)", "translateY(100%)");
  return baseAnimation.addElement(baseEl).easing("cubic-bezier(.36,.66,.04,1)").duration(450).addAnimation([backdropAnimation, wrapperAnimation]);
};
var mdEnterAnimation = (baseEl) => {
  const baseAnimation = createAnimation();
  const backdropAnimation = createAnimation();
  const wrapperAnimation = createAnimation();
  backdropAnimation.addElement(baseEl.querySelector("ion-backdrop")).fromTo("opacity", 0.01, "var(--backdrop-opacity)").beforeStyles({
    "pointer-events": "none"
  }).afterClearStyles(["pointer-events"]);
  wrapperAnimation.addElement(baseEl.querySelector(".action-sheet-wrapper")).fromTo("transform", "translateY(100%)", "translateY(0%)");
  return baseAnimation.addElement(baseEl).easing("cubic-bezier(.36,.66,.04,1)").duration(400).addAnimation([backdropAnimation, wrapperAnimation]);
};
var mdLeaveAnimation = (baseEl) => {
  const baseAnimation = createAnimation();
  const backdropAnimation = createAnimation();
  const wrapperAnimation = createAnimation();
  backdropAnimation.addElement(baseEl.querySelector("ion-backdrop")).fromTo("opacity", "var(--backdrop-opacity)", 0);
  wrapperAnimation.addElement(baseEl.querySelector(".action-sheet-wrapper")).fromTo("transform", "translateY(0%)", "translateY(100%)");
  return baseAnimation.addElement(baseEl).easing("cubic-bezier(.36,.66,.04,1)").duration(450).addAnimation([backdropAnimation, wrapperAnimation]);
};
var actionSheetIosCss = () => `.action-sheet-button-label-has-rich-content.sc-ion-action-sheet-ios,.alert-radio-label-has-rich-content.sc-ion-action-sheet-ios,.alert-checkbox-label-has-rich-content.sc-ion-action-sheet-ios,.select-option-label-has-rich-content.sc-ion-action-sheet-ios{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;gap:16px}.action-sheet-button-label-has-rich-content.sc-ion-action-sheet-ios,.alert-radio-label-has-rich-content.sc-ion-action-sheet-ios,.alert-checkbox-label-has-rich-content.sc-ion-action-sheet-ios,.select-option-content.sc-ion-action-sheet-ios{-ms-flex:1;flex:1}.action-sheet-button-label-text.sc-ion-action-sheet-ios,.alert-checkbox-label-text.sc-ion-action-sheet-ios,.alert-radio-label-text.sc-ion-action-sheet-ios,.select-option-label-text.sc-ion-action-sheet-ios{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;gap:12px}.select-option-start.sc-ion-action-sheet-ios,.select-option-end.sc-ion-action-sheet-ios{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;gap:8px}.select-option-description.sc-ion-action-sheet-ios{padding-left:0;padding-right:0;padding-top:5px;padding-bottom:0;display:block;color:var(--ion-color-step-700, var(--ion-text-color-step-300, #4d4d4d));font-size:0.75rem}.select-option-label.sc-ion-action-sheet-ios:not(.select-option-label-has-rich-content){text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.select-option-label-has-rich-content.sc-ion-action-sheet-ios{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center}ion-radio.select-option-has-rich-content.sc-ion-action-sheet-ios::part(label),ion-radio.select-option-has-rich-content.sc-ion-action-sheet-ios [part~="label"],ion-checkbox.select-option-has-rich-content.sc-ion-action-sheet-ios::part(label),ion-checkbox.select-option-has-rich-content.sc-ion-action-sheet-ios [part~="label"],.select-option-content.sc-ion-action-sheet-ios{-ms-flex:1;flex:1;white-space:normal}.select-option-start.sc-ion-action-sheet-ios>ion-avatar.sc-ion-action-sheet-ios,.select-option-start.sc-ion-action-sheet-ios>ion-img.sc-ion-action-sheet-ios,.select-option-start.sc-ion-action-sheet-ios>ion-thumbnail.sc-ion-action-sheet-ios,.select-option-start.sc-ion-action-sheet-ios>img.sc-ion-action-sheet-ios,.select-option-start.sc-ion-action-sheet-ios>svg.sc-ion-action-sheet-ios,.select-option-end.sc-ion-action-sheet-ios>ion-avatar.sc-ion-action-sheet-ios,.select-option-end.sc-ion-action-sheet-ios>ion-img.sc-ion-action-sheet-ios,.select-option-end.sc-ion-action-sheet-ios>ion-thumbnail.sc-ion-action-sheet-ios,.select-option-end.sc-ion-action-sheet-ios>img.sc-ion-action-sheet-ios,.select-option-end.sc-ion-action-sheet-ios>svg.sc-ion-action-sheet-ios{width:44px;height:44px}.select-option-start.sc-ion-action-sheet-ios>ion-icon.sc-ion-action-sheet-ios,.select-option-end.sc-ion-action-sheet-ios>ion-icon.sc-ion-action-sheet-ios{font-size:28px}.action-sheet-button-label-text.sc-ion-action-sheet-ios{-ms-flex-pack:center;justify-content:center}.select-option-has-rich-content.sc-ion-action-sheet-ios{-webkit-padding-end:16px;padding-inline-end:16px}.sc-ion-action-sheet-ios-h{--color:initial;--button-color-activated:var(--button-color);--button-color-focused:var(--button-color);--button-color-hover:var(--button-color);--button-color-selected:var(--button-color);--min-width:auto;--width:100%;--max-width:500px;--min-height:auto;--height:auto;--max-height:calc(100% - (var(--ion-safe-area-top) + var(--ion-safe-area-bottom)));-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;left:0;right:0;top:0;bottom:0;display:block;position:fixed;outline:none;font-family:var(--ion-font-family, inherit);-ms-touch-action:none;touch-action:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;z-index:1001}.overlay-hidden.sc-ion-action-sheet-ios-h{display:none}.action-sheet-wrapper.sc-ion-action-sheet-ios{left:0;right:0;bottom:0;-webkit-transform:translate3d(0,  100%,  0);transform:translate3d(0,  100%,  0);display:block;position:absolute;width:var(--width);min-width:var(--min-width);max-width:var(--max-width);height:var(--height);min-height:var(--min-height);max-height:var(--max-height);z-index:10;pointer-events:none}.action-sheet-button.sc-ion-action-sheet-ios{display:block;position:relative;width:100%;border:0;outline:none;background:var(--button-background);color:var(--button-color);font-family:inherit;overflow:hidden}.action-sheet-button.sc-ion-action-sheet-ios:disabled{color:var(--button-color-disabled);opacity:0.4}.action-sheet-button.sc-ion-action-sheet-ios:disabled ion-icon.sc-ion-action-sheet-ios{color:currentColor}.action-sheet-button-inner.sc-ion-action-sheet-ios{display:-ms-flexbox;display:flex;position:relative;-ms-flex-flow:row nowrap;flex-flow:row nowrap;-ms-flex-negative:0;flex-shrink:0;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;pointer-events:none;width:100%;height:100%;z-index:1}.action-sheet-container.sc-ion-action-sheet-ios{display:-ms-flexbox;display:flex;-ms-flex-flow:column;flex-flow:column;-ms-flex-pack:end;justify-content:flex-end;height:100%;max-height:calc(100vh - (var(--ion-safe-area-top, 0) + var(--ion-safe-area-bottom, 0)));max-height:calc(100dvh - (var(--ion-safe-area-top, 0) + var(--ion-safe-area-bottom, 0)))}.action-sheet-group.sc-ion-action-sheet-ios{-ms-flex-negative:2;flex-shrink:2;overscroll-behavior-y:contain;overflow-y:auto;-webkit-overflow-scrolling:touch;pointer-events:all;background:var(--background)}@media (any-pointer: coarse){.action-sheet-group.sc-ion-action-sheet-ios::-webkit-scrollbar{display:none}}.action-sheet-group-cancel.sc-ion-action-sheet-ios{-ms-flex-negative:0;flex-shrink:0;overflow:hidden}.action-sheet-button.sc-ion-action-sheet-ios::after{left:0;right:0;top:0;bottom:0;position:absolute;content:"";opacity:0}.action-sheet-selected.sc-ion-action-sheet-ios{color:var(--button-color-selected)}.action-sheet-selected.sc-ion-action-sheet-ios::after{background:var(--button-background-selected);opacity:var(--button-background-selected-opacity)}.action-sheet-button.ion-activated.sc-ion-action-sheet-ios{color:var(--button-color-activated)}.action-sheet-button.ion-activated.sc-ion-action-sheet-ios::after{background:var(--button-background-activated);opacity:var(--button-background-activated-opacity)}.action-sheet-button.ion-focused.sc-ion-action-sheet-ios:not(.ion-activated){color:var(--button-color-focused)}.action-sheet-button.ion-focused.sc-ion-action-sheet-ios:not(.ion-activated)::after{background:var(--button-background-focused);opacity:var(--button-background-focused-opacity)}.action-sheet-button.ion-focused.sc-ion-action-sheet-ios:not(.ion-activated).action-sheet-selected::after{background:var(--button-background-focused, var(--button-background-selected));opacity:var(--button-background-focused-opacity, var(--button-background-selected-opacity))}@media (any-hover: hover){.action-sheet-button.sc-ion-action-sheet-ios:not(:disabled):hover{color:var(--button-color-hover)}.action-sheet-button.sc-ion-action-sheet-ios:not(:disabled):hover::after{background:var(--button-background-hover);opacity:var(--button-background-hover-opacity)}}.sc-ion-action-sheet-ios-h{--background:var(--ion-overlay-background-color, var(--ion-color-step-100, var(--ion-background-color-step-100, #f9f9f9)));--backdrop-opacity:var(--ion-backdrop-opacity, 0.4);--button-background:linear-gradient(0deg, rgba(var(--ion-text-color-rgb, 0, 0, 0), 0.08), rgba(var(--ion-text-color-rgb, 0, 0, 0), 0.08) 50%, transparent 50%) bottom/100% 1px no-repeat transparent;--button-background-activated:var(--ion-text-color, #000);--button-background-activated-opacity:.08;--button-background-hover:currentColor;--button-background-hover-opacity:.04;--button-background-focused:currentColor;--button-background-focused-opacity:.12;--button-background-selected:var(--ion-color-step-150, var(--ion-background-color-step-150, var(--ion-background-color, #fff)));--button-background-selected-opacity:1;--button-color:var(--ion-color-primary, #0054e9);--button-color-disabled:var(--ion-color-step-850, var(--ion-text-color-step-150, #262626));--color:var(--ion-color-step-400, var(--ion-text-color-step-600, #999999));text-align:center}.action-sheet-wrapper.sc-ion-action-sheet-ios{-webkit-margin-start:auto;margin-inline-start:auto;-webkit-margin-end:auto;margin-inline-end:auto;margin-top:var(--ion-safe-area-top, 0);padding-bottom:var(--ion-safe-area-bottom, 0);-webkit-box-sizing:content-box;box-sizing:content-box}.action-sheet-container.sc-ion-action-sheet-ios{-webkit-padding-start:8px;padding-inline-start:8px;-webkit-padding-end:8px;padding-inline-end:8px;padding-top:0;padding-bottom:0}.action-sheet-group.sc-ion-action-sheet-ios{border-radius:13px;margin-bottom:8px}.action-sheet-group.sc-ion-action-sheet-ios:first-child{margin-top:10px}.action-sheet-group.sc-ion-action-sheet-ios:last-child{margin-bottom:10px}@supports ((-webkit-backdrop-filter: blur(0)) or (backdrop-filter: blur(0))){.action-sheet-translucent.sc-ion-action-sheet-ios-h .action-sheet-group.sc-ion-action-sheet-ios{background-color:transparent;-webkit-backdrop-filter:saturate(280%) blur(20px);backdrop-filter:saturate(280%) blur(20px)}.action-sheet-translucent.sc-ion-action-sheet-ios-h .action-sheet-title.sc-ion-action-sheet-ios,.action-sheet-translucent.sc-ion-action-sheet-ios-h .action-sheet-button.sc-ion-action-sheet-ios{background-color:transparent;background-image:-webkit-gradient(linear, left bottom, left top, from(rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.8)), to(rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.8))), -webkit-gradient(linear, left bottom, left top, from(rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.4)), color-stop(50%, rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.4)), color-stop(50%, rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.8)));background-image:linear-gradient(0deg, rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.8), rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.8) 100%), linear-gradient(0deg, rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.4), rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.4) 50%, rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.8) 50%);background-repeat:no-repeat;background-position:top, bottom;background-size:100% calc(100% - 1px), 100% 1px;-webkit-backdrop-filter:saturate(120%);backdrop-filter:saturate(120%)}.action-sheet-translucent.sc-ion-action-sheet-ios-h .action-sheet-button.ion-activated.sc-ion-action-sheet-ios{background-color:rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.7);background-image:none}.action-sheet-translucent.sc-ion-action-sheet-ios-h .action-sheet-cancel.sc-ion-action-sheet-ios{background:var(--button-background-selected)}}.action-sheet-title.sc-ion-action-sheet-ios{background:-webkit-gradient(linear, left bottom, left top, from(rgba(var(--ion-text-color-rgb, 0, 0, 0), 0.08)), color-stop(50%, rgba(var(--ion-text-color-rgb, 0, 0, 0), 0.08)), color-stop(50%, transparent)) bottom/100% 1px no-repeat transparent;background:linear-gradient(0deg, rgba(var(--ion-text-color-rgb, 0, 0, 0), 0.08), rgba(var(--ion-text-color-rgb, 0, 0, 0), 0.08) 50%, transparent 50%) bottom/100% 1px no-repeat transparent}.action-sheet-title.sc-ion-action-sheet-ios{-webkit-padding-start:10px;padding-inline-start:10px;-webkit-padding-end:10px;padding-inline-end:10px;padding-top:14px;padding-bottom:13px;color:var(--color, var(--ion-color-step-400, var(--ion-text-color-step-600, #999999)));font-size:max(13px, 0.8125rem);font-weight:400;text-align:center}.action-sheet-title.action-sheet-has-sub-title.sc-ion-action-sheet-ios{font-weight:600}.action-sheet-sub-title.sc-ion-action-sheet-ios{padding-left:0;padding-right:0;padding-top:6px;padding-bottom:0;font-size:max(13px, 0.8125rem);font-weight:400}.action-sheet-button.sc-ion-action-sheet-ios{-webkit-padding-start:14px;padding-inline-start:14px;-webkit-padding-end:14px;padding-inline-end:14px;padding-top:14px;padding-bottom:14px;min-height:56px;font-size:max(20px, 1.25rem);contain:content}.action-sheet-button.sc-ion-action-sheet-ios .action-sheet-icon.sc-ion-action-sheet-ios{-webkit-margin-end:0.3em;margin-inline-end:0.3em;font-size:max(28px, 1.75rem);pointer-events:none}.action-sheet-button.sc-ion-action-sheet-ios:last-child{background-image:none}.action-sheet-selected.sc-ion-action-sheet-ios{font-weight:bold}.action-sheet-cancel.sc-ion-action-sheet-ios{font-weight:600}.action-sheet-cancel.sc-ion-action-sheet-ios::after{background:var(--button-background-selected);opacity:var(--button-background-selected-opacity)}.action-sheet-destructive.sc-ion-action-sheet-ios,.action-sheet-destructive.ion-activated.sc-ion-action-sheet-ios,.action-sheet-destructive.ion-focused.sc-ion-action-sheet-ios{color:var(--ion-color-danger, #c5000f)}@media (any-hover: hover){.action-sheet-destructive.sc-ion-action-sheet-ios:hover{color:var(--ion-color-danger, #c5000f)}}`;
var actionSheetMdCss = () => `.action-sheet-button-label-has-rich-content.sc-ion-action-sheet-md,.alert-radio-label-has-rich-content.sc-ion-action-sheet-md,.alert-checkbox-label-has-rich-content.sc-ion-action-sheet-md,.select-option-label-has-rich-content.sc-ion-action-sheet-md{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;gap:16px}.action-sheet-button-label-has-rich-content.sc-ion-action-sheet-md,.alert-radio-label-has-rich-content.sc-ion-action-sheet-md,.alert-checkbox-label-has-rich-content.sc-ion-action-sheet-md,.select-option-content.sc-ion-action-sheet-md{-ms-flex:1;flex:1}.action-sheet-button-label-text.sc-ion-action-sheet-md,.alert-checkbox-label-text.sc-ion-action-sheet-md,.alert-radio-label-text.sc-ion-action-sheet-md,.select-option-label-text.sc-ion-action-sheet-md{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;gap:12px}.select-option-start.sc-ion-action-sheet-md,.select-option-end.sc-ion-action-sheet-md{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;gap:8px}.select-option-description.sc-ion-action-sheet-md{padding-left:0;padding-right:0;padding-top:5px;padding-bottom:0;display:block;color:var(--ion-color-step-700, var(--ion-text-color-step-300, #4d4d4d));font-size:0.75rem}.select-option-label.sc-ion-action-sheet-md:not(.select-option-label-has-rich-content){text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.select-option-label-has-rich-content.sc-ion-action-sheet-md{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center}ion-radio.select-option-has-rich-content.sc-ion-action-sheet-md::part(label),ion-radio.select-option-has-rich-content.sc-ion-action-sheet-md [part~="label"],ion-checkbox.select-option-has-rich-content.sc-ion-action-sheet-md::part(label),ion-checkbox.select-option-has-rich-content.sc-ion-action-sheet-md [part~="label"],.select-option-content.sc-ion-action-sheet-md{-ms-flex:1;flex:1;white-space:normal}.select-option-start.sc-ion-action-sheet-md>ion-avatar.sc-ion-action-sheet-md,.select-option-end.sc-ion-action-sheet-md>ion-avatar.sc-ion-action-sheet-md{width:40px;height:40px}.select-option-start.sc-ion-action-sheet-md>ion-icon.sc-ion-action-sheet-md,.select-option-end.sc-ion-action-sheet-md>ion-icon.sc-ion-action-sheet-md{font-size:24px}.select-option-start.sc-ion-action-sheet-md>ion-img.sc-ion-action-sheet-md,.select-option-start.sc-ion-action-sheet-md>img.sc-ion-action-sheet-md,.select-option-start.sc-ion-action-sheet-md>svg.sc-ion-action-sheet-md,.select-option-start.sc-ion-action-sheet-md>ion-thumbnail.sc-ion-action-sheet-md,.select-option-end.sc-ion-action-sheet-md>ion-img.sc-ion-action-sheet-md,.select-option-end.sc-ion-action-sheet-md>img.sc-ion-action-sheet-md,.select-option-end.sc-ion-action-sheet-md>svg.sc-ion-action-sheet-md,.select-option-end.sc-ion-action-sheet-md>ion-thumbnail.sc-ion-action-sheet-md{width:56px;height:56px}.select-option-start.sc-ion-action-sheet-md>video.sc-ion-action-sheet-md,.select-option-end.sc-ion-action-sheet-md>video.sc-ion-action-sheet-md{width:114px;height:56px}.sc-ion-action-sheet-md-h{--color:initial;--button-color-activated:var(--button-color);--button-color-focused:var(--button-color);--button-color-hover:var(--button-color);--button-color-selected:var(--button-color);--min-width:auto;--width:100%;--max-width:500px;--min-height:auto;--height:auto;--max-height:calc(100% - (var(--ion-safe-area-top) + var(--ion-safe-area-bottom)));-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;left:0;right:0;top:0;bottom:0;display:block;position:fixed;outline:none;font-family:var(--ion-font-family, inherit);-ms-touch-action:none;touch-action:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;z-index:1001}.overlay-hidden.sc-ion-action-sheet-md-h{display:none}.action-sheet-wrapper.sc-ion-action-sheet-md{left:0;right:0;bottom:0;-webkit-transform:translate3d(0,  100%,  0);transform:translate3d(0,  100%,  0);display:block;position:absolute;width:var(--width);min-width:var(--min-width);max-width:var(--max-width);height:var(--height);min-height:var(--min-height);max-height:var(--max-height);z-index:10;pointer-events:none}.action-sheet-button.sc-ion-action-sheet-md{display:block;position:relative;width:100%;border:0;outline:none;background:var(--button-background);color:var(--button-color);font-family:inherit;overflow:hidden}.action-sheet-button.sc-ion-action-sheet-md:disabled{color:var(--button-color-disabled);opacity:0.4}.action-sheet-button.sc-ion-action-sheet-md:disabled ion-icon.sc-ion-action-sheet-md{color:currentColor}.action-sheet-button-inner.sc-ion-action-sheet-md{display:-ms-flexbox;display:flex;position:relative;-ms-flex-flow:row nowrap;flex-flow:row nowrap;-ms-flex-negative:0;flex-shrink:0;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;pointer-events:none;width:100%;height:100%;z-index:1}.action-sheet-container.sc-ion-action-sheet-md{display:-ms-flexbox;display:flex;-ms-flex-flow:column;flex-flow:column;-ms-flex-pack:end;justify-content:flex-end;height:100%;max-height:calc(100vh - (var(--ion-safe-area-top, 0) + var(--ion-safe-area-bottom, 0)));max-height:calc(100dvh - (var(--ion-safe-area-top, 0) + var(--ion-safe-area-bottom, 0)))}.action-sheet-group.sc-ion-action-sheet-md{-ms-flex-negative:2;flex-shrink:2;overscroll-behavior-y:contain;overflow-y:auto;-webkit-overflow-scrolling:touch;pointer-events:all;background:var(--background)}@media (any-pointer: coarse){.action-sheet-group.sc-ion-action-sheet-md::-webkit-scrollbar{display:none}}.action-sheet-group-cancel.sc-ion-action-sheet-md{-ms-flex-negative:0;flex-shrink:0;overflow:hidden}.action-sheet-button.sc-ion-action-sheet-md::after{left:0;right:0;top:0;bottom:0;position:absolute;content:"";opacity:0}.action-sheet-selected.sc-ion-action-sheet-md{color:var(--button-color-selected)}.action-sheet-selected.sc-ion-action-sheet-md::after{background:var(--button-background-selected);opacity:var(--button-background-selected-opacity)}.action-sheet-button.ion-activated.sc-ion-action-sheet-md{color:var(--button-color-activated)}.action-sheet-button.ion-activated.sc-ion-action-sheet-md::after{background:var(--button-background-activated);opacity:var(--button-background-activated-opacity)}.action-sheet-button.ion-focused.sc-ion-action-sheet-md:not(.ion-activated){color:var(--button-color-focused)}.action-sheet-button.ion-focused.sc-ion-action-sheet-md:not(.ion-activated)::after{background:var(--button-background-focused);opacity:var(--button-background-focused-opacity)}.action-sheet-button.ion-focused.sc-ion-action-sheet-md:not(.ion-activated).action-sheet-selected::after{background:var(--button-background-focused, var(--button-background-selected));opacity:var(--button-background-focused-opacity, var(--button-background-selected-opacity))}@media (any-hover: hover){.action-sheet-button.sc-ion-action-sheet-md:not(:disabled):hover{color:var(--button-color-hover)}.action-sheet-button.sc-ion-action-sheet-md:not(:disabled):hover::after{background:var(--button-background-hover);opacity:var(--button-background-hover-opacity)}}.sc-ion-action-sheet-md-h{--background:var(--ion-overlay-background-color, var(--ion-background-color, #fff));--backdrop-opacity:var(--ion-backdrop-opacity, 0.32);--button-background:transparent;--button-background-selected:currentColor;--button-background-selected-opacity:0;--button-background-activated:transparent;--button-background-activated-opacity:0;--button-background-hover:currentColor;--button-background-hover-opacity:.04;--button-background-focused:currentColor;--button-background-focused-opacity:.12;--button-color:var(--ion-color-step-850, var(--ion-text-color-step-150, #262626));--button-color-disabled:var(--button-color);--color:rgba(var(--ion-text-color-rgb, 0, 0, 0), 0.54)}.action-sheet-wrapper.sc-ion-action-sheet-md{-webkit-margin-start:auto;margin-inline-start:auto;-webkit-margin-end:auto;margin-inline-end:auto;margin-top:var(--ion-safe-area-top, 0);margin-bottom:0}.action-sheet-title.sc-ion-action-sheet-md{-webkit-padding-start:16px;padding-inline-start:16px;-webkit-padding-end:16px;padding-inline-end:16px;padding-top:20px;padding-bottom:17px;min-height:60px;color:var(--color, rgba(var(--ion-text-color-rgb, 0, 0, 0), 0.54));font-size:1rem;text-align:start}.action-sheet-sub-title.sc-ion-action-sheet-md{padding-left:0;padding-right:0;padding-top:16px;padding-bottom:0;font-size:0.875rem}.action-sheet-group.sc-ion-action-sheet-md:first-child{padding-top:0}.action-sheet-group.sc-ion-action-sheet-md:last-child{padding-bottom:var(--ion-safe-area-bottom)}.action-sheet-button.sc-ion-action-sheet-md{-webkit-padding-start:16px;padding-inline-start:16px;-webkit-padding-end:16px;padding-inline-end:16px;padding-top:12px;padding-bottom:12px;position:relative;min-height:52px;font-size:1rem;text-align:start;contain:content;overflow:hidden}.action-sheet-icon.sc-ion-action-sheet-md{-webkit-margin-start:0;margin-inline-start:0;-webkit-margin-end:32px;margin-inline-end:32px;margin-top:0;margin-bottom:0;color:var(--color);font-size:1.5rem}.action-sheet-button-inner.sc-ion-action-sheet-md{-ms-flex-pack:start;justify-content:flex-start}.action-sheet-selected.sc-ion-action-sheet-md{font-weight:bold}`;
var ActionSheet = class {
  constructor(hostRef) {
    registerInstance(this, hostRef);
    this.didPresent = createEvent(this, "ionActionSheetDidPresent", 7);
    this.willPresent = createEvent(this, "ionActionSheetWillPresent", 7);
    this.willDismiss = createEvent(this, "ionActionSheetWillDismiss", 7);
    this.didDismiss = createEvent(this, "ionActionSheetDidDismiss", 7);
    this.didPresentShorthand = createEvent(this, "didPresent", 7);
    this.willPresentShorthand = createEvent(this, "willPresent", 7);
    this.willDismissShorthand = createEvent(this, "willDismiss", 7);
    this.didDismissShorthand = createEvent(this, "didDismiss", 7);
  }
  delegateController = createDelegateController(this);
  lockController = createLockController();
  triggerController = createTriggerController();
  wrapperEl;
  groupEl;
  gesture;
  hasRadioButtons = false;
  presented = false;
  lastFocus;
  animation;
  /**
   * The ID of the currently active/selected radio button.
   * Used for keyboard navigation and ARIA attributes.
   */
  activeRadioId;
  get el() {
    return getElement(this);
  }
  /** @internal */
  overlayIndex;
  /** @internal */
  delegate;
  /** @internal */
  hasController = false;
  /**
   * If `true`, the keyboard will be automatically dismissed when the overlay is presented.
   */
  keyboardClose = true;
  /**
   * Animation to use when the action sheet is presented.
   */
  enterAnimation;
  /**
   * Animation to use when the action sheet is dismissed.
   */
  leaveAnimation;
  /**
   * An array of buttons for the action sheet.
   */
  buttons = [];
  buttonsChanged() {
    const radioButtons = this.getRadioButtons();
    this.hasRadioButtons = radioButtons.length > 0;
    if (this.hasRadioButtons) {
      const checkedButton = radioButtons.find((b) => b.htmlAttributes?.["aria-checked"] === "true");
      if (checkedButton) {
        const allButtons = this.getButtons();
        const checkedIndex = allButtons.indexOf(checkedButton);
        this.activeRadioId = this.getButtonId(checkedButton, checkedIndex);
      }
    }
  }
  /**
   * Additional classes to apply for custom CSS. If multiple classes are
   * provided they should be separated by spaces.
   */
  cssClass;
  /**
   * If `true`, the action sheet will be dismissed when the backdrop is clicked.
   */
  backdropDismiss = true;
  /**
   * Title for the action sheet.
   */
  header;
  /**
   * Subtitle for the action sheet.
   */
  subHeader;
  /**
   * If `true`, the action sheet will be translucent.
   * Only applies when the mode is `"ios"` and the device supports
   * [`backdrop-filter`](https://developer.mozilla.org/en-US/docs/Web/CSS/backdrop-filter#Browser_compatibility).
   */
  translucent = false;
  /**
   * If `true`, the action sheet will animate.
   */
  animated = true;
  /**
   * Additional attributes to pass to the action sheet.
   */
  htmlAttributes;
  /**
   * If `true`, the action sheet will open. If `false`, the action sheet will close.
   * Use this if you need finer grained control over presentation, otherwise
   * just use the actionSheetController or the `trigger` property.
   * Note: `isOpen` will not automatically be set back to `false` when
   * the action sheet dismisses. You will need to do that in your code.
   */
  isOpen = false;
  onIsOpenChange(newValue, oldValue) {
    if (newValue === true && oldValue === false) {
      this.present();
    } else if (newValue === false && oldValue === true) {
      this.dismiss();
    }
  }
  /**
   * An ID corresponding to the trigger element that
   * causes the action sheet to open when clicked.
   */
  trigger;
  triggerChanged() {
    const { trigger, el, triggerController } = this;
    if (trigger) {
      triggerController.addClickListener(el, trigger);
    }
  }
  /**
   * Emitted after the action sheet has presented.
   */
  didPresent;
  /**
   * Emitted before the action sheet has presented.
   */
  willPresent;
  /**
   * Emitted before the action sheet has dismissed.
   */
  willDismiss;
  /**
   * Emitted after the action sheet has dismissed.
   */
  didDismiss;
  /**
   * Emitted after the action sheet has presented.
   * Shorthand for ionActionSheetWillDismiss.
   */
  didPresentShorthand;
  /**
   * Emitted before the action sheet has presented.
   * Shorthand for ionActionSheetWillPresent.
   */
  willPresentShorthand;
  /**
   * Emitted before the action sheet has dismissed.
   * Shorthand for ionActionSheetWillDismiss.
   */
  willDismissShorthand;
  /**
   * Emitted after the action sheet has dismissed.
   * Shorthand for ionActionSheetDidDismiss.
   */
  didDismissShorthand;
  /**
   * Present the action sheet overlay after it has been created.
   */
  async present() {
    const unlock = await this.lockController.lock();
    await this.delegateController.attachViewToDom();
    await present(this, "actionSheetEnter", iosEnterAnimation, mdEnterAnimation);
    unlock();
  }
  /**
   * Dismiss the action sheet overlay after it has been presented.
   * This is a no-op if the overlay has not been presented yet. If you want
   * to remove an overlay from the DOM that was never presented, use the
   * [remove](https://developer.mozilla.org/en-US/docs/Web/API/Element/remove) method.
   *
   * @param data Any data to emit in the dismiss events.
   * @param role The role of the element that is dismissing the action sheet.
   * This can be useful in a button handler for determining which button was
   * clicked to dismiss the action sheet. Some examples include:
   * `"cancel"`, `"destructive"`, `"selected"`, and `"backdrop"`.
   */
  async dismiss(data, role) {
    const unlock = await this.lockController.lock();
    const dismissed = await dismiss(this, data, role, "actionSheetLeave", iosLeaveAnimation, mdLeaveAnimation);
    if (dismissed) {
      this.delegateController.removeViewFromDom();
    }
    unlock();
    return dismissed;
  }
  /**
   * Returns a promise that resolves when the action sheet did dismiss.
   */
  onDidDismiss() {
    return eventMethod(this.el, "ionActionSheetDidDismiss");
  }
  /**
   * Returns a promise that resolves when the action sheet will dismiss.
   *
   */
  onWillDismiss() {
    return eventMethod(this.el, "ionActionSheetWillDismiss");
  }
  async buttonClick(button) {
    const role = button.role;
    if (isCancel(role)) {
      return this.dismiss(button.data, role);
    }
    const shouldDismiss = await this.callButtonHandler(button);
    if (shouldDismiss) {
      return this.dismiss(button.data, button.role);
    }
    return Promise.resolve();
  }
  async callButtonHandler(button) {
    if (button) {
      const rtn = await safeCall(button.handler);
      if (rtn === false) {
        return false;
      }
    }
    return true;
  }
  /**
   * Get all buttons regardless of role.
   */
  getButtons() {
    return this.buttons.map((b) => {
      return typeof b === "string" ? { text: b } : b;
    });
  }
  /**
   * Get all radio buttons (buttons with role="radio").
   */
  getRadioButtons() {
    return this.getButtons().filter((b) => {
      const role = b.htmlAttributes?.role;
      return role === "radio" && !isCancel(role);
    });
  }
  /**
   * Handle radio button selection and update aria-checked state.
   *
   * @param button The radio button that was selected.
   */
  selectRadioButton(button) {
    const buttonId = this.getButtonId(button);
    this.activeRadioId = buttonId;
  }
  /**
   * Get or generate an ID for a button.
   *
   * @param button The button for which to get the ID.
   * @param index Optional index of the button in the buttons array.
   * @returns The ID of the button.
   */
  getButtonId(button, index) {
    if (button.id) {
      return button.id;
    }
    const allButtons = this.getButtons();
    const buttonIndex = index !== void 0 ? index : allButtons.indexOf(button);
    return `action-sheet-button-${this.overlayIndex}-${buttonIndex}`;
  }
  onBackdropTap = () => {
    this.dismiss(void 0, BACKDROP);
  };
  dispatchCancelHandler = (ev) => {
    const role = ev.detail.role;
    if (isCancel(role)) {
      const cancelButton = this.getButtons().find((b) => b.role === "cancel");
      this.callButtonHandler(cancelButton);
    }
  };
  /**
   * When the action sheet has radio buttons, we want to follow the
   * keyboard navigation pattern for radio groups:
   * - Arrow Down/Right: Move to the next radio button (wrap to first if at end)
   * - Arrow Up/Left: Move to the previous radio button (wrap to last if at start)
   * - Space/Enter: Select the focused radio button and trigger its handler
   */
  onKeydown(ev) {
    if (!this.hasRadioButtons || !this.presented) {
      return;
    }
    const target = ev.target;
    if (!this.el.contains(target) || !target.classList.contains("action-sheet-button") || target.getAttribute("role") !== "radio") {
      return;
    }
    const radios = Array.from(this.el.querySelectorAll('.action-sheet-button[role="radio"]')).filter((el) => !el.disabled);
    const currentIndex = radios.findIndex((radio) => radio.id === target.id);
    if (currentIndex === -1) {
      return;
    }
    const allButtons = this.getButtons();
    const radioButtons = this.getRadioButtons();
    const buttonIdMap = /* @__PURE__ */ new Map();
    radioButtons.forEach((b) => {
      const allIndex = allButtons.indexOf(b);
      const buttonId = this.getButtonId(b, allIndex);
      buttonIdMap.set(buttonId, b);
    });
    let nextEl;
    if (["ArrowDown", "ArrowRight"].includes(ev.key)) {
      ev.preventDefault();
      ev.stopPropagation();
      nextEl = currentIndex === radios.length - 1 ? radios[0] : radios[currentIndex + 1];
    } else if (["ArrowUp", "ArrowLeft"].includes(ev.key)) {
      ev.preventDefault();
      ev.stopPropagation();
      nextEl = currentIndex === 0 ? radios[radios.length - 1] : radios[currentIndex - 1];
    } else if (ev.key === " " || ev.key === "Enter") {
      ev.preventDefault();
      ev.stopPropagation();
      const button = buttonIdMap.get(target.id);
      if (button) {
        this.selectRadioButton(button);
        this.buttonClick(button);
      }
      return;
    }
    if (nextEl) {
      const button = buttonIdMap.get(nextEl.id);
      if (button) {
        this.selectRadioButton(button);
        nextEl.focus();
      }
    }
  }
  connectedCallback() {
    prepareOverlay(this.el);
    this.triggerChanged();
  }
  disconnectedCallback() {
    if (this.gesture) {
      this.gesture.destroy();
      this.gesture = void 0;
    }
    this.triggerController.removeClickListener();
    if (this.presented) {
      cleanupRootFocusTrapAccessibility();
    }
  }
  componentWillLoad() {
    if (!this.htmlAttributes?.id) {
      setOverlayId(this.el);
    }
    this.buttonsChanged();
  }
  componentDidLoad() {
    const { groupEl, wrapperEl } = this;
    if (!this.gesture && getIonMode(this) === "ios" && wrapperEl && groupEl) {
      readTask(() => {
        const isScrollable = groupEl.scrollHeight > groupEl.clientHeight;
        if (!isScrollable) {
          this.gesture = createButtonActiveGesture(wrapperEl, (refEl) => refEl.classList.contains("action-sheet-button"));
          this.gesture.enable(true);
        }
      });
    }
    if (this.isOpen === true) {
      raf(() => this.present());
    }
    this.triggerChanged();
  }
  renderActionSheetButtons(filteredButtons) {
    const mode = getIonMode(this);
    const { activeRadioId } = this;
    return filteredButtons.map((b, index) => {
      const isRadio = b.htmlAttributes?.role === "radio";
      const buttonId = this.getButtonId(b, index);
      const radioButtons = this.getRadioButtons();
      const isActiveRadio = isRadio && buttonId === activeRadioId;
      const isFirstRadio = isRadio && b === radioButtons[0];
      let tabIndex;
      if (isRadio) {
        if (isActiveRadio) {
          tabIndex = 0;
        } else if (!activeRadioId && isFirstRadio) {
          tabIndex = 0;
        } else {
          tabIndex = -1;
        }
      } else {
        tabIndex = void 0;
      }
      const htmlAttrs = __spreadValues({}, b.htmlAttributes);
      if (isRadio) {
        htmlAttrs["aria-checked"] = isActiveRadio ? "true" : "false";
      }
      const richButton = b;
      const optionLabelOptions = {
        id: buttonId,
        label: richButton.text,
        startContent: richButton.startContent,
        endContent: richButton.endContent,
        description: richButton.description
      };
      return h("button", __spreadProps(__spreadValues({}, htmlAttrs), { role: isRadio ? "radio" : void 0, type: "button", id: buttonId, class: __spreadValues(__spreadValues({}, buttonClass(b)), isRadio && { "action-sheet-selected": isActiveRadio }), onClick: () => {
        if (isRadio) {
          this.selectRadioButton(b);
        }
        this.buttonClick(b);
      }, disabled: b.disabled, tabIndex }), h("span", { class: "action-sheet-button-inner" }, b.icon && h("ion-icon", { icon: b.icon, "aria-hidden": "true", lazy: false, class: "action-sheet-icon" }), renderOptionLabel(optionLabelOptions, "action-sheet-button-label", true)), mode === "md" && h("ion-ripple-effect", null));
    });
  }
  render() {
    const { header, htmlAttributes, overlayIndex, hasRadioButtons } = this;
    const mode = getIonMode(this);
    const allButtons = this.getButtons();
    const cancelButton = allButtons.find((b) => b.role === "cancel");
    const buttons = allButtons.filter((b) => b.role !== "cancel");
    const headerID = `action-sheet-${overlayIndex}-header`;
    return h(Host, __spreadProps(__spreadValues({ key: "7685831da9a78b73473246a2cea95cefa79a53c3", role: "dialog", "aria-modal": "true", "aria-labelledby": header !== void 0 ? headerID : null, tabindex: "-1" }, htmlAttributes), { style: {
      zIndex: `${2e4 + this.overlayIndex}`
    }, class: __spreadProps(__spreadValues({
      [mode]: true
    }, getClassMap(this.cssClass)), {
      "overlay-hidden": true,
      "action-sheet-translucent": this.translucent
    }), onIonActionSheetWillDismiss: this.dispatchCancelHandler, onIonBackdropTap: this.onBackdropTap }), h("ion-backdrop", { key: "c70f00e401cac99b89412d1adb867f35bc855d57", tappable: this.backdropDismiss }), h("div", { key: "3332893ce3098f1435875480b1269b2821d41660", tabindex: "0", "aria-hidden": "true" }), h("div", { key: "eb406b0a9e303d6f94c5c7aa99c6f4c089bfbd41", class: "action-sheet-wrapper ion-overlay-wrapper", ref: (el) => this.wrapperEl = el }, h("div", { key: "92ec855379f10e1e0bfce6ff68b45d3cda0c137c", class: "action-sheet-container" }, h("div", { key: "bc88a396d75396f574961471bf7e6c4edb513353", class: "action-sheet-group", ref: (el) => this.groupEl = el, role: hasRadioButtons ? "radiogroup" : void 0 }, header !== void 0 && h("div", { key: "33329e0193818888bdcaa443ff5ea301802e0787", id: headerID, class: {
      "action-sheet-title": true,
      "action-sheet-has-sub-title": this.subHeader !== void 0
    } }, header, this.subHeader && h("div", { key: "92ac5a9217a12b7417f7aca9c4fdb7bf6b051364", class: "action-sheet-sub-title" }, this.subHeader)), this.renderActionSheetButtons(buttons)), cancelButton && h("div", { key: "020463b830fa48fc3ae647ea64f2aaa4d0969305", class: "action-sheet-group action-sheet-group-cancel" }, h("button", __spreadProps(__spreadValues({ key: "cefa9c70a2233f6652a81b1a2eae6e717712144d" }, cancelButton.htmlAttributes), { type: "button", class: buttonClass(cancelButton), onClick: () => this.buttonClick(cancelButton) }), h("span", { key: "56d7e2f8bfb3644e4476895164d334445fda9b2f", class: "action-sheet-button-inner" }, cancelButton.icon && h("ion-icon", { key: "6a4a49254ec5cd96f4e0dce9447f90d8cac81913", icon: cancelButton.icon, "aria-hidden": "true", lazy: false, class: "action-sheet-icon" }), cancelButton.text), mode === "md" && h("ion-ripple-effect", { key: "7d3c6e8d70b0922ea0f75520856285ce1005c891" }))))), h("div", { key: "958fc43e603c6a7f5d1e649d3326fce0f163b5d0", tabindex: "0", "aria-hidden": "true" }));
  }
  static get watchers() {
    return {
      "buttons": [{
        "buttonsChanged": 0
      }],
      "isOpen": [{
        "onIsOpenChange": 0
      }],
      "trigger": [{
        "triggerChanged": 0
      }]
    };
  }
};
var buttonClass = (button) => {
  return __spreadValues({
    "action-sheet-button": true,
    "ion-activatable": !button.disabled,
    "ion-focusable": !button.disabled,
    [`action-sheet-${button.role}`]: button.role !== void 0
  }, getClassMap(button.cssClass));
};
ActionSheet.style = {
  ios: actionSheetIosCss(),
  md: actionSheetMdCss()
};
export {
  ActionSheet as ion_action_sheet
};
//# sourceMappingURL=ion-action-sheet.entry-GUEBMT4V.js.map
