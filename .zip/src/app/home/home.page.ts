import { Component } from '@angular/core';
import { CalcButton } from './calculator';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: false
})
export class HomePage {
  displayValue = '0';

  private operand = '';
  private operator = '';

  /** true = lo que se ve es un resultado, no algo tecleado por el usuario. */
  private isNewEntry = false;

  buttons: CalcButton[] = [
    { label: 'AC', value: 'clear', type: 'clear' },
    { label: 'sen', value: 'sin', type: 'function' },
    { label: 'cos', value: 'cos', type: 'function' },
    { label: '÷', value: '/', type: 'operator' },

    { label: '7', value: '7', type: 'number' },
    { label: '8', value: '8', type: 'number' },
    { label: '9', value: '9', type: 'number' },
    { label: '×', value: '*', type: 'operator' },

    { label: '4', value: '4', type: 'number' },
    { label: '5', value: '5', type: 'number' },
    { label: '6', value: '6', type: 'number' },
    { label: '−', value: '-', type: 'operator' },

    { label: '1', value: '1', type: 'number' },
    { label: '2', value: '2', type: 'number' },
    { label: '3', value: '3', type: 'number' },
    { label: '+', value: '+', type: 'operator' },

    { label: 'tan', value: 'tan', type: 'function' },
    { label: '0', value: '0', type: 'number' },
    { label: '.', value: '.', type: 'decimal' },
    { label: '=', value: '=', type: 'equal' },
  ];

  onButtonPress(button: CalcButton) {
    if (
      this.displayValue === 'Error' &&
      button.type !== 'clear' &&
      button.type !== 'number'
    ) {
      return;
    }

    if (button.type === 'clear') {
      this.displayValue = '0';
      this.operand = '';
      this.operator = '';
      this.isNewEntry = false;
    } else if (button.type === 'number') {
      if (this.isNewEntry) {
        this.displayValue = button.value;
        this.isNewEntry = false;
      } else {
        this.displayValue =
          this.displayValue === '0'
            ? button.value
            : this.displayValue + button.value;
      }
    } else if (button.type === 'decimal') {
      if (this.isNewEntry) {
        this.displayValue = '0.';
        this.isNewEntry = false;
      } else if (!this.displayValue.includes('.')) {
        this.displayValue += '.';
      }
    } else if (button.type === 'function') {
      this.applyFunction(button.value);
    } else if (button.type === 'operator') {
      if (this.operator && !this.isNewEntry) {
        this.displayValue = this.calculate();

        if (this.displayValue === 'Error') {
          this.operand = '';
          this.operator = '';
          this.isNewEntry = true;
          return;
        }
      }

      this.operand = this.displayValue;
      this.operator = button.value;
      this.isNewEntry = true;
    } else if (button.type === 'equal') {
      if (!this.operator) {
        return;
      }

      this.displayValue = this.calculate();
      this.operand = '';
      this.operator = '';
      this.isNewEntry = true;
    }
  }

  private applyFunction(fn: string) {
    const value = parseFloat(this.displayValue);
    const angle = (value * Math.PI) / 180;
    let result = 0;

    switch (fn) {
      case 'sin':
        result = Math.sin(angle);
        break;
      case 'cos':
        result = Math.cos(angle);
        break;
      case 'tan':
        if (Math.abs(Math.cos(angle)) < 1e-12) {
          this.displayValue = 'Error';
          this.isNewEntry = true;
          return;
        }
        result = Math.tan(angle);
        break;
    }

    this.displayValue = this.clean(result);
    this.isNewEntry = true;
  }

  private calculate(): string {
    const a = parseFloat(this.operand);
    const b = parseFloat(this.displayValue);
    let result = 0;

    switch (this.operator) {
      case '+':
        result = a + b;
        break;
      case '-':
        result = a - b;
        break;
      case '*':
        result = a * b;
        break;
      case '/':
        if (b === 0) {
          return 'Error';
        }
        result = a / b;
        break;
    }

    return this.clean(result);
  }

  private clean(value: number): string {
    const rounded = parseFloat(value.toPrecision(12));
    return (Math.abs(rounded) < 1e-12 ? 0 : rounded).toString();
  }
}