export type ButtonType =
  | 'number' // 0-9
  | 'decimal' // el punto
  | 'operator' // + - * /
  | 'function' // sen, cos, tan
  | 'equal' // =
  | 'clear'; // AC

export interface CalcButton {
  label: string;
  value: string;
  type: ButtonType;
}
